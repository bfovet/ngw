prompt var1 = &1
prompt var2 = &2
prompt db_local = &&db_local